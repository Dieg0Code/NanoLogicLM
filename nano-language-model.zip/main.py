def main():
    print("Hello from nano-language-model!")


if __name__ == "__main__":
    main()
