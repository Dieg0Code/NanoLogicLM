"""Paquete del tokenizer — contiene los special tokens y el tokenizer BPE."""

from src.tokenizer.special_tokens import SPECIAL_TOKENS

__all__ = ["SPECIAL_TOKENS"]
