# src/training/ — Pipeline de entrenamiento de NanoLogic.
